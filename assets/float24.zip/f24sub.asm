f24rsub:
;-AHL + CDE ==> AHL
;Destroys BC,DE
;
xor $80
jp f24add

f24sub:
;AHL - CDE ==> AHL
;Destroys BC,DE
;
ld b,a
ld a,c
xor $80
ld c,a
ld a,b
jp f24add



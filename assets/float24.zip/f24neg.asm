f24neg:
;-AHL ==> AHL

;-(+0) ==> +0
or a
ret z

;otherwise, negate
xor 80h
ret


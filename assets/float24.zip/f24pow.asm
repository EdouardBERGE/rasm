
f24pow:
;x^y ==> AHL

; save y
push de
push bc

;ln(x)
call f24log

;*y
pop bc
pop de
call f24mul

jp f24exp

include 'i16tof24.asm' ; HL=>AHL
include 'f24toi16.asm' ; AHL=>HL
include 'rand.asm'
include 'mul16.asm'
include 'sqrt16.asm'
include 'f24add.asm'   ;AHL + CDE ==> AHL
include 'f24mul.asm'   ;AHL * CDE ==> AHL
include 'f24sub.asm'   ;AHL - CDE ==> AHL
include 'f24cmp.asm'   ;AHL ? CDE ==> z+c
include 'f24div.asm'   ;AHL / CDE ==> AHL
include 'f24sqrt.asm'  ;sqrt(AHL) ==> AHL
include 'f24sqr.asm'   ;AHL * AHL ==> AHL
include 'f24mod1.asm'  ;AHL % 1   ==> AHL
include 'f24abs.asm'   ;abs(AHL)  ==> AHL
include 'f24sin.asm'   ;sin(AHL)  ==> AHL
include 'f24cos.asm'   ;cos(AHL)  ==> AHL
include 'f24tan.asm'   ;tan(AHL)  ==> AHL
include 'f24neg.asm'   ;-AHL      ==> AHL
include 'f24rand.asm'  ;rand(0/1) ==> AHL
; extended library requested for low, exp, pow
include 'f24div_pow2.asm' ;AHL/2^B ==> AHL
include 'f24mul3.asm'     ;AHL*3 ==> AHL
include 'f24mul2.asm'     ;AHL*3 ==> AHL
include 'f24geomean.asm'  ;sqrt(AHL*CDE) ==> AHL
include 'f24amean.asm'    ;(AHL+CDE)/2 ==> AHL
include 'f24bg.asm'       ;1/BG(AHL,CDE) ==> AHL
include 'f24log.asm'      ;log(AHL) ==> AHL
include 'f24exp.asm'
include 'f24pow.asm'      ;AHL^CDE ==> AHL


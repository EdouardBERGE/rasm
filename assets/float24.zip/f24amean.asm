
f24amean:
;(AHL+CDE) ==> AHL

;Make sure x+y won't overflow
;save A
ld b,a
and $7F
jr z,f24amean_nooverflow
cp $7E
jr z,f24amean_overflow

ld a,c
and $7F
jr z,f24amean_nooverflow
cp $7E
jr z,f24amean_overflow

f24amean_nooverflow:
ld a,b
call f24add
f24div2:
ld b,a
and $7F
ld a,b
ret z

ld b,a
and $7F
inc a
ld a,b
ret m
dec a
ret

f24amean_overflow:
;need to decrement the exponents first
ld a,b
push de
push bc
call f24div2
pop bc
ex (sp),hl
push af
ld a,c
call f24div2
pop bc
pop de
ld c,b
jp f24add



f24abs:
;abs(AHL) ==> AHL
and $7F
ret
